import mongoose from 'mongoose';
import Category from '../models/Category.js';

const isValidId = id => mongoose.Types.ObjectId.isValid(id);

export const getAllCategories = async (req, res) => {
  try {
    const cats = await Category.find();
    res.json(cats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getCategory = async (req, res) => {
  const { id } = req.params;
  if (!isValidId(id)) return res.status(400).json({ error: 'ID invalide' });
  const cat = await Category.findById(id);
  if (!cat) return res.status(404).json({ error: 'Catégorie non trouvée' });
  res.json(cat);
};

export const createCategory = async (req, res) => {
  try {
    const newCat = await Category.create(req.body);
    res.status(201).json(newCat);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

export const updateCategory = async (req, res) => {
  const { id } = req.params;
  if (!isValidId(id)) return res.status(400).json({ error: 'ID invalide' });
  const updated = await Category.findByIdAndUpdate(id, req.body, { new: true });
  if (!updated) return res.status(404).json({ error: 'Catégorie non trouvée' });
  res.json(updated);
};

export const deleteCategory = async (req, res) => {
  const { id } = req.params;
  if (!isValidId(id)) return res.status(400).json({ error: 'ID invalide' });
  const deleted = await Category.findByIdAndDelete(id);
  if (!deleted) return res.status(404).json({ error: 'Catégorie non trouvée' });
  res.status(204).end();
};
