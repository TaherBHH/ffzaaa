
import mongoose from 'mongoose';
import Card from '../models/Card.js';
import Category from '../models/Category.js';

// Vérifie qu'une chaîne est un ObjectId Mongo valide
const isValidObjectId = id => mongoose.Types.ObjectId.isValid(id);


async function resolveCategoryId(categoryParam) {
  // Si c'est un ObjectId valide, on cherche directement
  if (isValidObjectId(categoryParam)) {
    const catById = await Category.findById(categoryParam);
    if (!catById) {
      throw { status: 404, message: 'Catégorie non trouvée (par id)' };
    }
    return catById._id;
  }
  // Sinon, on cherche par nom
  const catByName = await Category.findOne({ name: categoryParam });
  if (!catByName) {
    throw { status: 404, message: 'Catégorie non trouvée (par nom)' };
  }
  return catByName._id;
}

// GET /api/cards → lister toutes les cartes
export const getAllCards = async (req, res) => {
  try {
    const cards = await Card.find().populate('category');
    return res.status(200).json(cards);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};

// GET /api/cards/:id → récupérer une seule carte
export const getCardById = async (req, res) => {
  const { id } = req.params;
  if (!isValidObjectId(id)) {
    return res.status(400).json({ error: 'ID de carte invalide' });
  }
  try {
    const card = await Card.findById(id).populate('category');
    if (!card) {
      return res.status(404).json({ error: 'Carte non trouvée' });
    }
    return res.status(200).json(card);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};

// POST /api/cards → créer une carte (avec nom ou id de catégorie)
export const createCard = async (req, res) => {
  try {
    const { category, ...rest } = req.body;
    if (!category) {
      return res.status(400).json({ error: 'Champ "category" requis' });
    }
    const categoryId = await resolveCategoryId(category);
    const newCard = new Card({ ...rest, category: categoryId });
    const savedCard = await newCard.save();
    // Peuple la catégorie dans la réponse
    await savedCard.populate('category');
    return res.status(201).json(savedCard);
  } catch (err) {
    if (err.status) {
      return res.status(err.status).json({ error: err.message });
    }
    return res.status(400).json({ error: err.message });
  }
};

// PUT /api/cards/:id → mettre à jour une carte
export const updateCard = async (req, res) => {
  const { id } = req.params;
  if (!isValidObjectId(id)) {
    return res.status(400).json({ error: 'ID de carte invalide' });
  }
  try {
    const update = { ...req.body };
    if (req.body.category) {
      update.category = await resolveCategoryId(req.body.category);
    }
    const updatedCard = await Card.findByIdAndUpdate(id, update, {
      new: true,
      runValidators: true
    }).populate('category');
    if (!updatedCard) {
      return res.status(404).json({ error: 'Carte non trouvée' });
    }
    return res.status(200).json(updatedCard);
  } catch (err) {
    if (err.status) {
      return res.status(err.status).json({ error: err.message });
    }
    return res.status(400).json({ error: err.message });
  }
};

// DELETE /api/cards/:id → supprimer une carte
export const deleteCard = async (req, res) => {
  const { id } = req.params;
  if (!isValidObjectId(id)) {
    return res.status(400).json({ error: 'ID de carte invalide' });
  }
  try {
    const deleted = await Card.findByIdAndDelete(id);
    if (!deleted) {
      return res.status(404).json({ error: 'Carte non trouvée' });
    }
    return res.status(204).end();
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};
// GET /api/cards/category/:name → lister les cartes d'une catégorie par son nom
export const getCardsByCategoryName = async (req, res) => {
  const { name } = req.params;
  try {
    // Recherche insensible à la casse
    const category = await Category.findOne({
      name: new RegExp(`^${name}$`, 'i')
    });
    if (!category) {
      return res.status(404).json({ error: 'Catégorie non trouvée' });
    }

    // Récupère les cartes liées à cet _id de catégorie
    const cards = await Card.find({ category: category._id })
                            .populate('category');
    return res.status(200).json(cards);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};