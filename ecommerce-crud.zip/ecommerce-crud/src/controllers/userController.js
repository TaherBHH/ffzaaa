import mongoose from 'mongoose';
import User   from '../models/User.js';
import Card   from '../models/Card.js';

const isValidId = id => mongoose.Types.ObjectId.isValid(id);

// POST /api/users → créer un user
export const createUser = async (req, res) => {
  try {
    const user = await User.create(req.body);
    return res.status(201).json(user);
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }
};

// GET /api/users → lister tous les users
export const getUsers = async (req, res) => {
  try {
    const users = await User.find();
    return res.status(200).json(users);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};

// GET /api/users/:id/cart → récupérer le panier (tableau peuplé)
export const getCart = async (req, res) => {
  const { id } = req.params;
  if (!isValidId(id)) return res.status(400).json({ error: 'User ID invalide' });
  const user = await User.findById(id).populate('cart');
  if (!user) return res.status(404).json({ error: 'Utilisateur non trouvé' });
  return res.status(200).json(user.cart);
};

// POST /api/users/:id/cart/:cardId/:quantity
export const addToCart = async (req, res) => {
    const { id: userId, cardId, quantity } = req.params;
    const qty = parseInt(quantity, 10);
  
    // Validation des IDs et de la quantité
    if (
      !mongoose.Types.ObjectId.isValid(userId) ||
      !mongoose.Types.ObjectId.isValid(cardId) ||
      !Number.isInteger(qty) ||
      qty < 1
    ) {
      return res.status(400).json({ error: 'Paramètres invalides' });
    }
  
    try {
      const [user, card] = await Promise.all([
        User.findById(userId),
        Card.findById(cardId)
      ]);
      if (!user) return res.status(404).json({ error: 'Utilisateur non trouvé' });
      if (!card) return res.status(404).json({ error: 'Carte non trouvée' });
  
      // On pousse 'qty' fois ce cardId dans user.cart
      for (let i = 0; i < qty; i++) {
        user.cart.push(cardId);
      }
  
      await user.save();
      await user.populate('cart');
      return res.status(200).json(user.cart);
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  };
// DELETE /api/users/:id/cart/:cardId → retirer toutes les occurrences
export const removeCartItem = async (req, res) => {
  const { id: userId, cardId } = req.params;
  if (!isValidId(userId) || !isValidId(cardId))
    return res.status(400).json({ error: 'IDs invalides' });

  const user = await User.findById(userId);
  if (!user) return res.status(404).json({ error: 'Utilisateur non trouvé' });

  user.cart = user.cart.filter(c => !c.equals(cardId));
  await user.save();
  await user.populate('cart');
  return res.status(200).json(user.cart);
};

// DELETE /api/users/:id/cart → vider complètement le panier
export const clearCart = async (req, res) => {
  const { id } = req.params;
  if (!isValidId(id)) return res.status(400).json({ error: 'User ID invalide' });

  const user = await User.findById(id);
  if (!user) return res.status(404).json({ error: 'Utilisateur non trouvé' });

  user.cart = [];
  await user.save();
  return res.status(204).end();
};



// 1. GET /api/users/:id/cards
export const getUserCards = async (req, res) => {
    const { id } = req.params;
    if (!isValidId(id)) {
      return res.status(400).json({ error: 'User ID invalide' });
    }
    const user = await User.findById(id).populate('cart');
    if (!user) {
      return res.status(404).json({ error: 'Utilisateur non trouvé' });
    }
    // user.cart est un tableau d'objets Card peuplés
    return res.status(200).json(user.cart);
  };
  
  // 2. GET /api/users/:id/cart/total
  export const getCartTotal = async (req, res) => {
    const { id } = req.params;
    if (!isValidId(id)) {
      return res.status(400).json({ error: 'User ID invalide' });
    }
    const user = await User.findById(id).populate('cart');
    if (!user) {
      return res.status(404).json({ error: 'Utilisateur non trouvé' });
    }
    // Somme des prix de chaque carte (répétée pour la quantité)
    const total = user.cart.reduce((sum, card) => sum + (card.price || 0), 0);
    return res.status(200).json({ total });
  };