// src/config/db.js
import mongoose from 'mongoose';
import dotenv from 'dotenv';
dotenv.config();                                 // 

// 
const uri = process.env.MONGO_URI 
  || 'mongodb://127.0.0.1:27017/ecommerce-crud';

// 3️⃣ Log pour vérification
console.log('→ MongoDB URI:', uri);

const connectDB = async () => {
  try {
    await mongoose.connect(uri, {
      family: 4,               // 
      serverSelectionTimeoutMS: 5000,
    });
    console.log('MongoDB connecté');
  } catch (err) {
    console.error('Erreur de connexion MongoDB :', err.message);
    process.exit(1);
  }
};

export default connectDB;