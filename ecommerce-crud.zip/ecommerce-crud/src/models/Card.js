import mongoose from 'mongoose';

const cardSchema = new mongoose.Schema({
  title:     { type: String, required: true },
  description: String,
  price:     { type: Number, required: true },
  imageUrl:  String,
  createdAt: { type: Date, default: Date.now },
  category: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Category',
    required: true
  }
});

const Card = mongoose.model('Card', cardSchema);
export default Card;