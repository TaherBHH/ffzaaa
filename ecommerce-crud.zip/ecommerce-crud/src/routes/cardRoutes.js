import express from 'express';
import {
  getAllCards,
  getCardById,
  createCard,
  updateCard,
  deleteCard,
  getCardsByCategoryName 
} from '../controllers/cardController.js';

const router = express.Router();

router.route('/')
  .get(getAllCards) //hedhi tjib beha 
  .post(createCard);

router.route('/:id')
  .get(getCardById)
  .put(updateCard)
  .delete(deleteCard);

  router.get('/category/:name', getCardsByCategoryName);


export default router;