import express from 'express';
import {
  getAllCategories,
  getCategory,
  createCategory,
  updateCategory,
  deleteCategory
} from '../controllers/categoryController.js';

const router = express.Router();

router.get('/', getAllCategories);  // GET /api/categories
router.get('/:id', getCategory);       // GET /api/categories/:id
router.post('/', createCategory);    // POST /api/categories
router.put('/:id', updateCategory);    // PUT /api/categories/:id
router.delete('/:id', deleteCategory); // DELETE /api/categories/:id

export default router;
