import express from 'express';
import {
    createUser,
  getUsers,
  getCart,
  addToCart,
  removeCartItem,
  clearCart,
  getUserCards,
  getCartTotal
} from '../controllers/userController.js';

const router = express.Router();
router.post('/',                 createUser);         // POST   /api/users
router.get('/',                  getUsers);           // GET    /api/users

router.get('/:id/cards',           getUserCards);
router.get('/:id/cart/total',      getCartTotal);

// ... tes routes users existantes

// POST /api/users/:id/cart/:cardId/:quantity
router.post('/:id/cart/:cardId/:quantity', addToCart);

// GET  /api/users/:id/cart
router.get('/:id/cart', getCart);

// DELETE /api/users/:id/cart/:cardId
router.delete('/:id/cart/:cardId', removeCartItem);

// DELETE /api/users/:id/cart
router.delete('/:id/cart', clearCart);

export default router;